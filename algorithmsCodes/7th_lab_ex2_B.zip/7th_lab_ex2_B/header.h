#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

void d2b(int,int**,int*);

#endif // HEADER_H_INCLUDED
